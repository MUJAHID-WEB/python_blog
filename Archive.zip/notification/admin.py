from django.contrib import admin

from .models import Notificaiton


admin.site.register(Notificaiton)
