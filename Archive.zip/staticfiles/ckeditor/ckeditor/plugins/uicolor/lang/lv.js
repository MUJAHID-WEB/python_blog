﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","lv",{title:"UI krāsas izvēle",preview:"Priekšskatījums",config:"Ielīmējiet šo rindu jūsu config.js failā",predefined:"Predefinēti krāsu komplekti"});