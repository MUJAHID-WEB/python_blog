from django import forms

from .models import Blog

#from ckeditor.fields import RichTextField


class TextForm(forms.Form):
    text = forms.CharField(widget=forms.Textarea, required=True)


